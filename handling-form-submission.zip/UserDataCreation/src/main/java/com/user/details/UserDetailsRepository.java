package com.user.details;

import org.springframework.data.mongodb.repository.MongoRepository;


public interface UserDetailsRepository extends MongoRepository<User, String> {
}
