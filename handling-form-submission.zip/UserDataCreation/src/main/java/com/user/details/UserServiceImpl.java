package com.user.details;

import com.poiji.bind.Poiji;
import com.poiji.option.PoijiOptions;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.util.*;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDataRepository repository;

    public void saveDatatoExcel(User user) {

        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("User Details");

        Map<String, Object[]> data = new TreeMap<String, Object[]>();
        data.put("1", new Object[]{"USERNAME", "FIRSTNAME", "LASTNAME", "AGE", "EMAIL"});
        data.put("2", new Object[]{user.getUsername(), user.getFirstName(), user.getLastName(), user.getAge(), user.getEmail()});
        data.put("3", new Object[]{"VDK", "VALAR", "DK", "53", "VD@gmail.com"});

        //Iterate over data and write to sheet
        Set<String> keyset = data.keySet();
        int rownum = 0;
        for (String key : keyset) {
            Row row = sheet.createRow(rownum++);
            Object[] objArr = data.get(key);
            int cellnum = 0;
            for (Object obj : objArr) {
                Cell cell = row.createCell(cellnum++);
                if (obj instanceof String)
                    cell.setCellValue((String) obj);
                else if (obj instanceof Integer)
                    cell.setCellValue((Integer) obj);
            }
        }
        try {
            //Write the workbook in file system
            FileOutputStream out = new FileOutputStream(new File("C://Valar/UserDetails.xlsx"));
            workbook.write(out);
            out.close();
            System.out.println("User data saved");
        } catch (Exception e) {
            e.printStackTrace();
        }
        //Read Data
        File file = new File("C://Valar/UserDetails.xlsx");
        PoijiOptions options = PoijiOptions.PoijiOptionsBuilder.settings()
                .build();
        List<User> users = Poiji.fromExcel(file, User.class, options);
    }

    public void saveToDB(User user) {
        user.setFirstName("VD1");
        user.setLastName("DK");
        user.setAge("607");
        user.setEmail("test@gmail.com");
        repository.insert(user);
        repository.save(user);
    }

}
