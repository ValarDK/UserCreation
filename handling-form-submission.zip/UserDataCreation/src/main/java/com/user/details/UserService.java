package com.user.details;

public interface UserService {

    public void saveToDB(User user);

    public void saveDatatoExcel(User user);

}
