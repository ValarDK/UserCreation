package com.user.details;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class UserController {

	private final UserService userService;

	public UserController(UserService userService) {
		this.userService = userService;
			}

	@GetMapping("/createUser")
	public String createUser(Model model) {
		model.addAttribute("user", new User());
		return "createUser";
	}

	@RequestMapping(value = "/saveUser", method = RequestMethod.POST)
	public String saveUser(@ModelAttribute("user") User user, Model model) {
		System.out.println(user.getUsername()+ user.getFirstName()+ user.getLastName()+user.getAge()+user.getEmail());
		userService.saveDatatoExcel(user);
		userService.saveToDB(user);
		return "result";
	}

}
